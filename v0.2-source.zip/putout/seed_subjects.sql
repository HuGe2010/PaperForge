INSERT INTO "Subject" (id, name, code, "order", "createdAt", "updatedAt") VALUES
('subj-chinese','语文','chinese',1, now(), now()),
('subj-math','数学','math',2, now(), now()),
('subj-english','英语','english',3, now(), now()),
('subj-physics','物理','physics',4, now(), now()),
('subj-chemistry','化学','chemistry',5, now(), now()),
('subj-biology','生物','biology',6, now(), now()),
('subj-politics','政治','politics',7, now(), now()),
('subj-history','历史','history',8, now(), now()),
('subj-geography','地理','geography',9, now(), now())
ON CONFLICT (code) DO NOTHING;
