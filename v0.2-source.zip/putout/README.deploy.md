# 智能试卷与试题整理系统 — NAS 部署指南（Docker Compose）

本目录是一份**自包含、可放到 NAS 上直接运行**的部署包。所有镜像都在 NAS 本地从源码构建（无需预编译二进制），适合 fnOS / 群晖 / 任何带 Docker 的环境。

> 已包含阶段：P1 基础脚手架 · P2 题库/学科/标签 · P3 权限/用户/审核台 · P4 OCR 录题流水线（7 步：上传→自动框选→人工核对框→AI 识别→标注属性与所属试卷→入库→后台 AI 解答，必须配置真实密钥，不再编题）· P5 智能组卷。
> 未包含（后续阶段）：在线考试、自动评分、试卷导出下载等（接口已预留权限位，待后续迭代）。

> **变更记录（2026-08-16）**：修复 backend 启动崩溃 `TypeError: Cannot read properties of undefined (reading 'baseUrl')`——`RealVlmProvider` 被误注册为 Nest provider，DI 无参实例化导致崩溃。已从 `IngestModule.providers` 移除 `MockVlmProvider` / `RealVlmProvider`（二者本就在 `VlmService` 内按需手动 `new`，不应走 DI）。**重新部署必须 `docker compose up -d --build` 重建镜像**，否则仍跑旧镜像。
>
> **变更记录（2026-08-16 二次）**：修复「登录后不跳转」+ 健康检查 Redis down。
> 1. **前端登录不跳转**：`frontend/src/stores/auth.ts` 误用 `res.data.accessToken`（axios 拦截器已 `response.use(r=>r.data)` 解包，实际响应体即 `res` 本身），导致 `accessToken` 取到 `undefined`、`isLoggedIn` 恒 false，登录后路由守卫立即把 `/dashboard` 弹回 `/login`。改为 `res.accessToken`/`res.user`；`api/auth.ts` 返回类型对齐解包约定（`as unknown as Promise<LoginResult>`）；`fetchMe` 将 JWT payload 的 `sub` 归一化为 `id`。
> 2. **健康检查 Redis down**：`redis.module.ts` 的 `lazyConnect: true` + `enableOfflineQueue: false` 使首次 `ping()` 在 `connecting` 态被离线队列禁用策略直接抛 `Stream isn't writeable`，连接从未建立。移除 `lazyConnect` 让客户端在 Nest 启动时即建连；`health.controller.ts` 的 `redisCheck` 在 `status !== 'ready'` 时显式 `connect()` 兜底。现 `/api/health` 返回 200，Redis 状态 up。
> 重新部署仍需 `docker compose up -d --build`。
>
> **变更记录（2026-08-16 三次）**：修复「登录无反馈 / 正确密码也登不进」的排查盲区。
> 1. **401 静默失败**：`frontend/src/api/client.ts` 的响应拦截器对 401 分支**故意不弹提示**（只跳登录页），导致密码错误时前端"毫无反应、也无报错"。改为：当当前路由就是登录页时，401 直接 `ElMessage.error(后端消息)`（如"用户名或密码错误"），便于即时定位。
> 2. **登录防御性校验**：`LoginView.vue` 在 `auth.login` 成功后若 `!auth.isLoggedIn` 则提示"未能获取令牌"并返回，避免无声卡死。
> 3. **关键部署提醒**：上一轮修复的是**前端** `stores/auth.ts`（`.data` 误用），必须**连同前端镜像一起重建**。`docker compose up -d --build` 会同时重建 backend 与 frontend；若只重建 backend（`...--build backend`），前端仍跑旧的 `.data` 版本 → 登录永远拿不到 token → 表现为"正确/错误账号都没反应"。请务必执行**完整**的 `docker compose up -d --build`（不要只 build backend）。
>
> **变更记录（2026-08-16 四次）**：补齐「系统设置 → AI 配置」页面（此前是 ComingSoon 占位，用户无处填 Key）。
> - 现象：用户反馈"没地方填 key"；OCR 识题全是示例题（因未配真实 VLM 密钥，系统按设计回退 `MockVlmProvider`）。
> - 后端 `SettingsModule`（`GET/PUT /api/settings/:group`，AES-256-GCM 加密存密钥）与 `vlm.service`（`vlm` 组 `enabled==='true' && apiKey` 切换真实/Mock）本就就绪，缺的是前端入口。
> - 修复：新增 `frontend/src/api/settings.ts`、新增 `frontend/src/views/admin/SettingsView.vue`（双卡片「视觉模型（OCR 识题）/ 文本模型」，视觉模型含 启用开关 + Base URL + API Key(留空不覆盖) + 模型），`router/index.ts` 的 `admin-settings` 由 ComingSoon 改为该页（ADMIN 可见）。已 `vue-tsc` 0 错 + `vite build` 成功验证，并同步进 `putout/`。
> - 用法：重建前后端后，admin 登录 → 左侧「系统设置」→ 视觉模型卡片开开关 + 填 Key/Base URL/模型（如通义千问 `https://dashscope.aliyuncs.com/compatible-mode/v1` + `qwen-vl-max-latest`）→ 保存。之后 OCR「识别」即调用真实视觉模型，不再是示例题。

> **变更记录（2026-08-16 五次）**：OCR 录题流水线重构为 7 步，并接入真实 VLM + LLM（阿里云 DashScope），彻底移除"静默编题"。
> - 需求：原「上传→识别→审阅台」3 步改为「上传→自动框选→人工核对框→AI 识别→标注属性与所属试卷→入库→后台 AI 解答」。框选由 VLM 版面检测输出包围框；试卷名由 VLM 识别、人工可改；入库后后台异步调用文本模型生成解答。
> - 后端：`vlm-provider.interface.ts` 新增 `detect`（版面检测，返回 bbox 数组 + 试卷名）并保留 `recognize`（支持 bbox 区域提示）；`RealVlmProvider` 实现二者；`VlmService` **默认不再回退 Mock**——未配置真实密钥时直接报错提示（仅 `ALLOW_MOCK_VLM=1` 允许本地无密钥演示）。新增 `llm` 模块（`LlmService` 读 `llm` settings 组，默认 baseUrl 指向 DashScope 兼容端点）做后台解答。`IngestService` 拆分为 `detect/recognize/addBox/reviewItem(含 bbox+paperName)/approveItem(写 sourcePaperName + fire-and-forget LLM 解答)/getPageImage`；`IngestController` 新增 `POST /:id/detect`、`POST /items`、`GET /pages/:pageId/image`。`Question` 新增 `sourcePaperName/solution/llmModel`，`OcrItem`/`IngestPage` 新增 `paperName`，`OcrItemStatus` 新增 `DETECTED`（含迁移脚本）。
> - 前端：`IngestView.vue` 重写为 7 步流程 + 可拖拽/缩放/增删的 bbox 编辑器（框选图由 `GET /pages/:pageId/image` 流式返回）；审阅台新增「所属试卷」字段；`SettingsView.vue` 文本模型卡片指向 DashScope 并说明其驱动后台 AI 解答。`models.ts` / `api/ingest.ts` 同步补字段与端点。
> - 验证：后端 `nest build` EXIT 0；前端 `vue-tsc --noEmit && vite build` EXIT 0；均已同步进 `putout/`。
> - 部署：仍需完整 `docker compose up -d --build`（前后端镜像一并重建），首次需 `prisma migrate deploy` 应用新迁移（新增 DETECTED 枚举与三个字段）。
>
> **变更记录（2026-08-16 六次）**：「自动框选」改为本地 OCR 两阶段服务，不再依赖云端视觉模型。
> - 需求：原「自动框选」走 VLM 版面检测，坐标不稳定、且未配密钥时无法使用。改为**本地 PaddleOCR 两阶段**（OCR 框住所有文字 → 题号/标题正则分组 → 圈出单题框 + 标题框），无需任何 AI 密钥，对任意试卷页稳定可用。
> - 新增 `ocr/` 目录（FastAPI + PaddleOCR 服务，`POST /detect` 接收图片返回归一化题目框，`GET /health` 健康检查）与 `docker/Dockerfile.ocr`；`docker-compose.yml` 新增 `ocr` 服务（内存上限 1.5G，`OCR_SERVICE_URL=http://ocr:8000`）。
> - 后端：新增 `OcrDetectService`（读 imagePath/buffer → multipart 上传给 OCR 服务），`VlmService.detect()` 改走该服务；`recognize()`（AI 识题）仍走真实视觉模型。**框选与识题解耦：框选不需要密钥，识题才需要。**
> - 部署：**必须完整 `docker compose up -d --build`**（会多构建一个约 1.5G 的 OCR 镜像，首次构建较慢）。OCR 服务首次启动加载 PaddleOCR 模型约需数十秒（健康检查 `start_period=90s` 已覆盖），之后常驻。
> - 说明：OCR 版框选与 VLM 版对外接口完全一致（返回 `{boxes:[{bbox,type,confidence}]}` 归一化坐标），前端「AI 框选题目」按钮无需改动。

---

## 1. 目录结构

```
putout/
├── docker-compose.yml      # 编排：postgres / redis / backend / frontend / ocr
├── .env.example            # 环境变量模板（复制为 .env 后填写）
├── .dockerignore           # 构建上下文忽略规则（已配好）
├── docker/
│   ├── Dockerfile.backend  # NestJS 多阶段构建（含迁移 + seed 启动）
│   ├── Dockerfile.frontend # Vue3 静态构建 + nginx 反代
│   ├── Dockerfile.ocr      # FastAPI + PaddleOCR 框选服务
│   ├── nginx.conf          # 前端 SPA + /api 反代到 backend:3000
│   ├── init-postgres.sql   # 初始化 pg_trgm 扩展
│   └── fonts/              # 中文字体（预留）
├── ocr/                    # OCR 框选服务源码（PaddleOCR 两阶段）
│   ├── app.py              # FastAPI 服务：POST /detect + GET /health
│   └── requirements.txt    # paddleocr / paddlepaddle / fastapi 等
├── backend/                # 后端源码（含 prisma 迁移）
│   └── prisma/migrations/  # 初始建表迁移（首次自动执行）
└── frontend/               # 前端源码
```

---

## 2. 前置条件

- NAS 已安装 **Docker** 与 **Docker Compose v2**（`docker compose` 子命令）。
  - fnOS：应用中心装「Docker」即可。
  - 群晖：装 Container Manager。
- NAS 能访问互联网（**首次** `docker compose up --build` 需要拉取基础镜像并 `npm install`，之后断网也能跑）。
- 建议预留：PostgreSQL 数据约 50–200MB/年起，上传卷按使用量增长。
- 对外端口默认 **9280**（可在 `.env` 改 `WEB_PORT`）。

---

## 3. 部署步骤

```bash
# ① 把整个 putout/ 目录拷到 NAS 某处，例如 /vol1/@app/exam/putout
#   然后 SSH 进 NAS 进入该目录：

cd /path/to/putout

# ② 基于模板生成你的环境变量文件
cp .env.example .env

# ③ 编辑 .env，至少填写下面「必填项」三处（见第 4 节）
vi .env        # 或用你熟悉的编辑器

# ④ 一键构建并启动（-d 后台；--build 首次必须，会构建两个镜像）
docker compose up -d --build

# ⑤ 观察启动日志（首跑会建表 + 写入种子数据，约 1–2 分钟）
docker compose logs -f backend

# ⑥ 确认全部健康
docker compose ps
```

启动成功后访问：**http://<你的NAS内网IP>:9280**

---

## 4. `.env` 变量填写清单

打开 `.env`，需要你关心的分三类：**必填 / 建议改 / 一般不用动**。

### 4.1 必填（不填会导致启动失败或所有人都能进）

| 变量 | 示例 / 命令 | 说明 |
|------|------------|------|
| `POSTGRES_PASSWORD` | `Psql@2026$Nas` | 数据库密码。**务必改成强密码**，否则安全风险。 |
| `JWT_SECRET` | 见下 | Access Token 签名密钥，必须随机。 |
| `JWT_REFRESH_SECRET` | 见下 | Refresh Token 签名密钥，必须随机且与上不同。 |

生成两个随机密钥（在 NAS 上执行，把输出粘进 `.env`）：
```bash
openssl rand -base64 48   # 用于 JWT_SECRET
openssl rand -base64 48   # 用于 JWT_REFRESH_SECRET
```

### 4.2 建议改

| 变量 | 默认 | 说明 |
|------|------|------|
| `WEB_PORT` | `9280` | 前端对外端口。若与 NAS 其他服务冲突就改。 |
| `POSTGRES_USER` | `exam` | 一般不用改。 |
| `POSTGRES_DB` | `exam` | 一般不用改。 |
| `TZ` | `Asia/Shanghai` | 容器时区。 |

### 4.3 一般不用动（已有合理默认）

| 变量 | 默认 | 说明 |
|------|------|------|
| `JWT_ACCESS_TTL` | `1800` | Access Token 有效期（秒）=30 分钟。 |
| `JWT_REFRESH_TTL` | `604800` | Refresh Token 有效期（秒）=7 天。 |
| `UPLOAD_DIR` | `/app/uploads` | 上传文件根目录，对应挂载卷。 |
| `LLM_PROVIDER` / `LLM_BASE_URL` / `LLM_MODEL` | deepseek | 文本模型默认值（解题/打标签）。 |
| `VLM_PROVIDER` / `VLM_BASE_URL` / `VLM_MODEL` | qwen-vl-max-latest | 视觉模型默认值（识题）。 |

> ⚠️ **API Key 不要写进 `.env`！** 登录后在「系统设置 → AI 配置」页面由管理员填写，加密存库、运行时读取，绝不进镜像/compose/版本库（见第 6 节）。

---

## 5. 初始账号与首次登录

种子数据在**首次启动自动写入**（admin 账号、ADMIN/TEACHER/STUDENT 三角色、全部权限）。

- 地址：http://<NAS-IP>:9280
- 管理员账号：`admin`
- 初始密码：`Exam@2024!`
- **请登录后立即到「个人中心 / 用户管理」修改管理员密码。**

> 忘记管理员密码：进 NAS 容器执行
> `docker compose exec backend npx prisma db seed`（会重置 admin 密码为 `Exam@2024!`）。

---

## 6. 启用 AI 能力（识题 / 解题 / 打标签）

**框选题目（自动框选）已改用本地 OCR 服务，无需任何密钥**；其余 AI 能力仍需两套模型密钥，均在「系统设置」页面由管理员填写（AES-256-GCM 加密存库，绝不进镜像 / `.env`）：

- **视觉模型（OCR 识题）**：驱动「AI 识别题目」一步（按框识别题干/选项/解析），识别你上传的真实试卷。
  - 填 **API Key**、**Base URL**（OpenAI 兼容 `/v1` 端点，阿里云通义千问：`https://dashscope.aliyuncs.com/compatible-mode/v1`）、**模型**（如 `qwen-vl-max-latest`），并打开「启用真实视觉模型」开关。
- **文本模型（后台 AI 解题）**：题目「入库」后，系统**后台异步**调用该模型生成解析与解答并写回题库。
  - 填 **provider**（如 `dashscope`）、**Base URL**（同上 DashScope 兼容端点）、**API Key**、**模型**（如 `qwen-plus`）。

> ⚠️ **不再静默编题**：自本版本起，未配置视觉模型密钥时，「AI 识别」会**直接报错提示**，不会再返回编造的示例题。必须先在「系统设置」填好阿里云 DashScope 密钥，「识别」这一步才会真实工作。
> （仅当显式设置环境变量 `ALLOW_MOCK_VLM=1` 时，才允许本地无密钥演示，切勿用于生产录入。）
>
> ℹ️ **「自动框选」无需密钥**：框选走本地 PaddleOCR 两阶段服务（`ocr` 容器），点「AI 框选题目」即出框，不依赖云端视觉模型、不消耗任何 token。

### 7 步录题流水线

| 步骤 | 操作 | 说明 |
| --- | --- | --- |
| 1 | 上传图片 / PDF | 可选选择学科，用于 AI 标知识点 |
| 2 | 自动框选 | 本地 OCR 两阶段（PaddleOCR 框住文字 → 题号正则分组 → 圈出单题框 + 标题框），无需密钥 |
| 3 | 编辑框选 | 在编辑器里拖动 / 缩放 / 增删框，改动自动保存 |
| 4 | 识别题目 | 按每个框调用 VLM 识别题干、选项、解析、难度（需视觉模型密钥） |
| 5 | 审阅台 | 补全 / 修正题型、题干、难度、**所属试卷（题目来源）**、知识点、标签 |
| 6 | 批准入题 | 写入题库 |
| 7 | 后台 AI 解答 | 入库后自动调用文本模型生成解答，稍后可在题库查看（题目详情含解答与 AI 标记） |

填写位置（应用内，需 admin 角色）：用 admin 登录 → 左侧「系统设置」→ 分别填写「视觉模型（OCR 识题）」与「文本模型（后台 AI 解题）」两张卡片 → 保存后立即生效，无需重启。

> 密钥仅以 AES-256-GCM 加密存入 `settings` 表，不进镜像、不进 `.env`。API Key 留空表示不修改已有密钥。

支持的接口形态：OpenAI 兼容的 `/v1/chat/completions`（视觉模型传多模态内容，文本模型传文本对话）。

---

## 7. 数据持久化

所有有状态数据都挂在 NAS 本机目录 `./data/`（首次启动自动创建）：

```
putout/data/
├── postgres/   # PostgreSQL 数据文件（核心，备份重点）
├── redis/      # Redis 持久化（缓存/会话）
├── uploads/    # OCR 上传的试卷图片/PDF
└── exports/    # 试卷导出文件（后续阶段使用）
```

> 只要 `putout/data/` 目录不动，升级镜像、重启容器都不会丢数据。

---

## 8. 常用运维命令

```bash
docker compose ps                 # 查看五服务状态（postgres/redis/backend/frontend/ocr）
docker compose logs -f backend   # 跟踪后端日志
docker compose logs -f frontend  # 跟踪前端/ nginx 日志
docker compose logs -f ocr       # 跟踪 OCR 服务日志
docker compose restart           # 重启全部
docker compose down              # 停止并移除容器（数据保留在 ./data）
docker compose up -d --build     # 重新构建并启动（升级/改代码后用）
```

### 备份建议
- 定期备份 `putout/data/postgres/` 即可保全全部业务数据。
- 简单做法：`docker compose stop` 后打包 `data/`；或用 `pg_dump`（进 postgres 容器执行）。

### 停止 / 卸载
```bash
docker compose down      # 仅停服，数据保留
# 要彻底删除：再 rm -rf putout/data   （⚠️ 会清空所有数据）
```

---

## 9. 升级到新版本

1. 用新部署包覆盖 `putout/` 下的 `backend/`、`frontend/`、`docker/`、`docker-compose.yml`（保留你自己的 `.env` 和 `data/`）。
2. `docker compose up -d --build` 重新构建。
3. 数据库迁移是幂等的（`migrate deploy`），旧数据自动保留；若新版本新增表/字段，会在启动时自动补表。

---

## 10. 已知范围与限制（当前版本）

- ✅ 可用：登录鉴权、学科/知识点/标签管理、题库 CRUD、OCR 录题流水线（Mock/真实视觉模型）、智能组卷与预览。
- ⏳ 后续阶段（尚未实现，接口权限已预留）：在线考试、自动评分、试卷导出/下载（故 `/files/` 与导出功能暂未开放）、异步队列识别（当前为同步处理器，数据量不大时足够）。
- 🔒 安全提醒：`.env` 含数据库密码与 JWT 密钥，请勿提交到公开仓库；AI Key 一律走应用内配置，不落盘到 compose。

---

## 11. 故障排查速查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| 前端一直转圈 / 接口 404 | 后端未就绪或 `/api` 反代异常 | `docker compose ps` 看 backend 是否 healthy；看 backend 日志 |
| backend 一直 unhealthy | DB/Redis 没起来或迁移失败 | `docker compose logs backend`、`docker compose logs postgres` |
| 页面能开但登录报错 | JWT 密钥为空/被改 | 确认 `.env` 中 `JWT_SECRET`/`JWT_REFRESH_SECRET` 已填 |
| 上传文件重启后消失 | 没挂到 `./data/uploads` | 检查 compose 中 `./data/uploads:/app/uploads` 与 `UPLOAD_DIR=/app/uploads` |
| 「自动框选 / 识别」直接报错"未配置视觉模型密钥" | 未在「系统设置」填写视觉模型 Key 或未开「启用真实视觉模型」 | **注意：框选（自动框选）已改用本地 OCR，无需密钥；只有「AI 识别」才需密钥。** 系统设置 → 视觉模型卡片：开开关 + 填阿里云 DashScope 的 API Key / Base URL(`https://dashscope.aliyuncs.com/compatible-mode/v1`) / 模型(`qwen-vl-max-latest`)，保存后立即生效 |
| 「自动框选」报错"无法连接 OCR 服务 / OCR 服务响应超时" | `ocr` 容器未就绪或未启动 | `docker compose ps` 看 `exam-ocr` 是否 healthy；`docker compose logs -f ocr` 看是否还在加载模型（首次启动约需数十秒，健康检查 start_period=90s）；确认 backend 的 `OCR_SERVICE_URL` 默认 `http://ocr:8000` |
| 入库后题目没有 AI 解答 | 未配置「文本模型」密钥，或文本模型调用失败 | 系统设置 → 文本模型卡片填 DashScope 的 API Key / Base URL / 模型(`qwen-plus`)；解答在后台异步生成，稍后刷新题库详情查看；失败会记在 backend 日志（含 `AI 解答失败`） |
| 框选编辑器图片加载不出来 | 页面原图接口未授权或路径错误 | 确认以 TEACHER/ADMIN 角色登录；`GET /ingest/pages/:id/image` 需登录鉴权 |
| 「自动框选 / 识别」报 `VLM 模型名无效或该模型未在控制台开通`（含 `model_not_found` 404） | ① 视觉模型填的是**纯文本模型**（如 qwen-max / qwen-plus / Qwen3.x，不能读图）；② 模型名拼错；③ 用的是**百炼 MaaS 私有端点**（`*.maas.aliyuncs.com`）但 model 没填成控制台里的**精确部署名** | 视觉模型必须用**视觉(VL)模型**：公开 DashScope 填 `qwen-vl-max-latest` 或 `qwen-vl-plus`（不可用文本模型）；若用 MaaS 私有端点，model 必须精确等于你在百炼控制台部署时起的部署名，且该部署本身是视觉模型。报错信息现已给出具体 model / baseUrl 便于核对 |
